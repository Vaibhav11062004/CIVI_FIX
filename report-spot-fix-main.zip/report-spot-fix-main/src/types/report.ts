export type IssueType = 'Garbage' | 'Pothole' | 'Broken Streetlight';
export type ReportStatus = 'Open' | 'In Progress' | 'Resolved';

export interface Location {
  latitude: number;
  longitude: number;
  address?: string;
}

export interface Report {
  id: string;
  image_url: string;
  issue_type: IssueType;
  confidence: number;
  status: ReportStatus;
  created_at: string;
  latitude?: number;
  longitude?: number;
  address?: string;
}

export interface DetectionResult {
  issue_type: IssueType;
  confidence: number;
}

export interface DetectResponse {
  success: boolean;
  report?: Report;
  detection?: DetectionResult;
  error?: string;
}
