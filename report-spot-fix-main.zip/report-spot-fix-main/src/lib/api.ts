import { supabase } from '@/integrations/supabase/client';
import type { Report, DetectResponse, ReportStatus, Location } from '@/types/report';

export async function uploadAndDetect(file: File, location?: Location): Promise<DetectResponse> {
  const formData = new FormData();
  formData.append('image', file);
  
  if (location) {
    formData.append('latitude', location.latitude.toString());
    formData.append('longitude', location.longitude.toString());
    if (location.address) {
      formData.append('address', location.address);
    }
  }

  const { data, error } = await supabase.functions.invoke('detect-issue', {
    body: formData,
  });

  if (error) {
    console.error('Detection error:', error);
    return { success: false, error: error.message };
  }

  return data as DetectResponse;
}

export async function getReports(): Promise<Report[]> {
  const { data, error } = await supabase
    .from('reports')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching reports:', error);
    return [];
  }

  return (data as unknown as Report[]) || [];
}

export async function updateReportStatus(id: string, status: ReportStatus): Promise<boolean> {
  const { error } = await supabase
    .from('reports')
    .update({ status })
    .eq('id', id);

  if (error) {
    console.error('Error updating report:', error);
    return false;
  }

  return true;
}

export function getIssueColor(issueType: string): string {
  switch (issueType) {
    case 'Garbage':
      return 'issue-garbage';
    case 'Pothole':
      return 'issue-pothole';
    case 'Broken Streetlight':
      return 'issue-streetlight';
    default:
      return '';
  }
}
