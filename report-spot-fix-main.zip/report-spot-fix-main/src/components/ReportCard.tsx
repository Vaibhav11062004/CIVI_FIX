import { Trash2, Lightbulb, CircleDot, Clock, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Report } from '@/types/report';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { getIssueColor } from '@/lib/api';

interface ReportCardProps {
  report: Report;
}

const issueIcons = {
  'Garbage': Trash2,
  'Pothole': CircleDot,
  'Broken Streetlight': Lightbulb,
};

export function ReportCard({ report }: ReportCardProps) {
  const confidencePercent = Math.round(report.confidence * 100);
  const Icon = issueIcons[report.issue_type] || CircleDot;
  const timeAgo = formatDistanceToNow(new Date(report.created_at), { addSuffix: true });
  const colorClass = getIssueColor(report.issue_type);

  const statusClass = {
    'Open': 'status-open',
    'In Progress': 'status-in-progress',
    'Resolved': 'status-resolved',
  }[report.status];

  const borderColor = {
    'Garbage': 'border-l-issue-garbage',
    'Pothole': 'border-l-issue-pothole',
    'Broken Streetlight': 'border-l-issue-streetlight',
  }[report.issue_type];

  return (
    <Card className={cn(
      "overflow-hidden transition-all duration-200 hover:shadow-lg hover:-translate-y-1 animate-fade-in",
      `border-l-4 ${borderColor}`
    )}>
      <div className="aspect-video relative overflow-hidden bg-muted">
        <img
          src={report.image_url}
          alt={report.issue_type}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute top-3 left-3">
          <Badge 
            variant="secondary" 
            className={cn("flex items-center gap-1.5 shadow-md", colorClass)}
          >
            <Icon className="h-3 w-3" />
            {report.issue_type}
          </Badge>
        </div>
        <div className="absolute top-3 right-3">
          <Badge variant="secondary" className={cn("shadow-md", statusClass)}>
            {report.status}
          </Badge>
        </div>
      </div>
      
      <CardContent className="pt-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Confidence</span>
          <div className="flex items-center gap-2">
            <div className="h-1.5 w-16 bg-muted rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full",
                  colorClass === 'issue-garbage' && "bg-issue-garbage",
                  colorClass === 'issue-pothole' && "bg-issue-pothole",
                  colorClass === 'issue-streetlight' && "bg-issue-streetlight"
                )}
                style={{ width: `${confidencePercent}%` }}
              />
            </div>
            <span className="text-xs font-medium">{confidencePercent}%</span>
          </div>
        </div>

        {/* Location */}
        {(report.latitude && report.longitude) && (
          <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3 mt-0.5 shrink-0" />
            <span className="truncate">
              {report.address || `${report.latitude.toFixed(4)}, ${report.longitude.toFixed(4)}`}
            </span>
          </div>
        )}

        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span>Reported {timeAgo}</span>
        </div>
      </CardContent>
    </Card>
  );
}
