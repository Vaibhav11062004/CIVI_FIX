import { MapPin, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Location } from '@/types/report';
import { cn } from '@/lib/utils';

interface LocationDisplayProps {
  location: Location | null;
  isLoading: boolean;
  error: string | null;
  onRetry: () => void;
  compact?: boolean;
}

export function LocationDisplay({
  location,
  isLoading,
  error,
  onRetry,
  compact = false,
}: LocationDisplayProps) {
  if (isLoading) {
    return (
      <div className={cn(
        "flex items-center gap-2 text-muted-foreground",
        compact ? "text-xs" : "text-sm"
      )}>
        <Loader2 className={cn("animate-spin", compact ? "h-3 w-3" : "h-4 w-4")} />
        <span>Getting your location...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className={cn(
        "flex items-center gap-2",
        compact ? "text-xs" : "text-sm"
      )}>
        <AlertCircle className={cn("text-destructive", compact ? "h-3 w-3" : "h-4 w-4")} />
        <span className="text-destructive">{error}</span>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRetry}
          className="h-auto p-1"
        >
          <RefreshCw className="h-3 w-3" />
        </Button>
      </div>
    );
  }

  if (!location) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={onRetry}
        className={cn("gap-2", compact && "h-8 text-xs")}
      >
        <MapPin className={compact ? "h-3 w-3" : "h-4 w-4"} />
        Get Location
      </Button>
    );
  }

  return (
    <div className={cn(
      "flex items-start gap-2",
      compact ? "text-xs" : "text-sm"
    )}>
      <MapPin className={cn(
        "text-primary shrink-0 mt-0.5",
        compact ? "h-3 w-3" : "h-4 w-4"
      )} />
      <div className="flex-1 min-w-0">
        {location.address ? (
          <p className="text-foreground truncate" title={location.address}>
            {location.address}
          </p>
        ) : (
          <p className="text-muted-foreground">
            {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
          </p>
        )}
      </div>
      <Button
        variant="ghost"
        size="sm"
        onClick={onRetry}
        className="h-auto p-1 shrink-0"
        title="Refresh location"
      >
        <RefreshCw className="h-3 w-3" />
      </Button>
    </div>
  );
}
