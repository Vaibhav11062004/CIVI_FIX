import { useState, useCallback, useEffect } from 'react';
import { Upload, Image as ImageIcon, X, Loader2, Camera, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CameraCapture } from '@/components/CameraCapture';
import { LocationDisplay } from '@/components/LocationDisplay';
import { useLocation } from '@/hooks/useLocation';
import { cn } from '@/lib/utils';
import type { Location } from '@/types/report';

interface ImageUploaderProps {
  onUpload: (file: File, location?: Location) => void;
  isLoading: boolean;
}

export function ImageUploader({ onUpload, isLoading }: ImageUploaderProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  
  const { location, isLoading: locationLoading, error: locationError, getLocation, clearError } = useLocation();

  // Auto-fetch location when component mounts
  useEffect(() => {
    getLocation();
  }, []);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      return;
    }
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFile(file);
    }
  }, [handleFile]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleCameraCapture = (file: File) => {
    handleFile(file);
    setShowCamera(false);
  };

  const clearPreview = () => {
    setPreview(null);
    setSelectedFile(null);
  };

  const handleSubmit = () => {
    if (selectedFile) {
      onUpload(selectedFile, location || undefined);
    }
  };

  if (showCamera) {
    return (
      <CameraCapture
        onCapture={handleCameraCapture}
        onClose={() => setShowCamera(false)}
      />
    );
  }

  return (
    <div className="w-full space-y-4">
      {/* Location Display */}
      <div className="p-3 bg-accent/50 rounded-lg border">
        <div className="flex items-center gap-2 mb-2 text-sm font-medium text-foreground">
          <MapPin className="h-4 w-4 text-primary" />
          Current Location
        </div>
        <LocationDisplay
          location={location}
          isLoading={locationLoading}
          error={locationError}
          onRetry={() => {
            clearError();
            getLocation();
          }}
        />
      </div>

      {!preview ? (
        <div className="space-y-3">
          {/* Camera Button - Prominent for mobile */}
          <Button
            onClick={() => setShowCamera(true)}
            variant="default"
            size="lg"
            className="w-full h-14 text-base gap-3"
          >
            <Camera className="h-6 w-6" />
            Take Photo
          </Button>

          {/* Drag & Drop Area */}
          <div className="relative">
            <div className="absolute inset-x-0 top-0 flex items-center">
              <div className="flex-1 border-t border-border" />
              <span className="px-3 text-xs text-muted-foreground bg-card">or upload a file</span>
              <div className="flex-1 border-t border-border" />
            </div>
          </div>

          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={cn(
              "relative flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-xl transition-all duration-200 cursor-pointer mt-6",
              dragActive
                ? "border-primary bg-primary/5 scale-[1.02]"
                : "border-border hover:border-primary/50 hover:bg-accent/30"
            )}
          >
            <input
              type="file"
              accept="image/*"
              onChange={handleInputChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="flex flex-col items-center gap-2 text-center px-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">
                  Drop image here or click to browse
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  JPEG, PNG, WebP (max 10MB)
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="relative rounded-xl overflow-hidden border bg-card animate-scale-in">
          <img
            src={preview}
            alt="Preview"
            className="w-full h-64 object-cover"
          />
          <button
            onClick={clearPreview}
            disabled={isLoading}
            className="absolute top-3 right-3 p-2 rounded-full bg-background/90 hover:bg-background transition-colors shadow-md disabled:opacity-50"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
            <div className="flex items-center gap-2 text-white text-sm">
              <ImageIcon className="h-4 w-4" />
              <span className="truncate">{selectedFile?.name}</span>
            </div>
            {location && (
              <div className="flex items-center gap-1.5 text-white/80 text-xs mt-1">
                <MapPin className="h-3 w-3" />
                <span className="truncate">{location.address || `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {preview && (
        <Button
          onClick={handleSubmit}
          disabled={isLoading}
          className="w-full h-12 text-base font-medium"
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Analyzing with YOLOv8...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-5 w-5" />
              Submit Report
            </>
          )}
        </Button>
      )}
    </div>
  );
}
