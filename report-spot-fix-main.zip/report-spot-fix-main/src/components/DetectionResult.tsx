import { CheckCircle2, AlertTriangle, Trash2, Lightbulb, CircleDot, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Report } from '@/types/report';
import { cn } from '@/lib/utils';
import { getIssueColor } from '@/lib/api';

interface DetectionResultProps {
  report: Report;
}

const issueIcons = {
  'Garbage': Trash2,
  'Pothole': CircleDot,
  'Broken Streetlight': Lightbulb,
};

export function DetectionResult({ report }: DetectionResultProps) {
  const confidencePercent = Math.round(report.confidence * 100);
  const Icon = issueIcons[report.issue_type] || CircleDot;
  const colorClass = getIssueColor(report.issue_type);

  return (
    <Card className={cn(
      "animate-slide-up overflow-hidden",
      `border-${colorClass}/30`
    )}>
      <div className={cn(
        "px-6 py-4 flex items-center gap-3",
        `bg-${colorClass}-light`
      )}>
        <div className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full text-white",
          colorClass === 'issue-garbage' && "bg-issue-garbage",
          colorClass === 'issue-pothole' && "bg-issue-pothole",
          colorClass === 'issue-streetlight' && "bg-issue-streetlight"
        )}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">Issue Detected!</h3>
          <p className="text-sm text-muted-foreground">
            YOLOv8 AI has analyzed your image
          </p>
        </div>
        <CheckCircle2 className="h-6 w-6 text-status-resolved" />
      </div>
      
      <CardContent className="pt-6 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Issue Type</span>
          <Badge 
            variant="outline" 
            className={cn("px-3 py-1 text-sm font-medium", colorClass)}
          >
            {report.issue_type}
          </Badge>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Confidence</span>
            <span className="text-sm font-semibold">{confidencePercent}%</span>
          </div>
          <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
            <div
              className={cn(
                "h-full transition-all duration-500 rounded-full",
                colorClass === 'issue-garbage' && "bg-issue-garbage",
                colorClass === 'issue-pothole' && "bg-issue-pothole",
                colorClass === 'issue-streetlight' && "bg-issue-streetlight",
                confidencePercent < 70 && "bg-destructive"
              )}
              style={{ width: `${confidencePercent}%` }}
            />
          </div>
          {confidencePercent < 70 && (
            <div className="flex items-center gap-2 text-xs text-destructive mt-1">
              <AlertTriangle className="h-3 w-3" />
              Low confidence - manual review recommended
            </div>
          )}
        </div>

        {/* Location Display */}
        {(report.latitude && report.longitude) && (
          <div className="pt-2 border-t">
            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 text-primary mt-0.5" />
              <div className="flex-1">
                <span className="text-sm text-muted-foreground block">Location</span>
                <span className="text-sm font-medium">
                  {report.address || `${report.latitude.toFixed(6)}, ${report.longitude.toFixed(6)}`}
                </span>
              </div>
            </div>
          </div>
        )}

        <div className="pt-2 border-t">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Status</span>
            <Badge variant="outline" className="status-open">
              Open
            </Badge>
          </div>
        </div>

        <p className="text-xs text-center text-muted-foreground pt-2">
          Your report has been submitted and is now visible in the public feed.
        </p>
      </CardContent>
    </Card>
  );
}
