import { Trash2, Lightbulb, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TableCell, TableRow } from '@/components/ui/table';
import type { Report, ReportStatus } from '@/types/report';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface AdminReportRowProps {
  report: Report;
  onStatusChange: (id: string, status: ReportStatus) => void;
  isUpdating: boolean;
}

export function AdminReportRow({ report, onStatusChange, isUpdating }: AdminReportRowProps) {
  const isGarbage = report.issue_type === 'Garbage';
  const confidencePercent = Math.round(report.confidence * 100);
  const Icon = isGarbage ? Trash2 : Lightbulb;
  const formattedDate = format(new Date(report.created_at), 'MMM d, yyyy HH:mm');

  const statusClass = {
    'Open': 'status-open',
    'In Progress': 'status-in-progress',
    'Resolved': 'status-resolved',
  }[report.status];

  return (
    <TableRow className="group">
      <TableCell>
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-lg overflow-hidden bg-muted flex-shrink-0">
            <img
              src={report.image_url}
              alt={report.issue_type}
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={() => window.open(report.image_url, '_blank')}
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </TableCell>
      <TableCell>
        <Badge 
          variant="outline" 
          className={cn(
            "flex items-center gap-1.5 w-fit",
            isGarbage ? "issue-garbage" : "issue-streetlight"
          )}
        >
          <Icon className="h-3 w-3" />
          {report.issue_type}
        </Badge>
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          <div className="h-1.5 w-12 bg-muted rounded-full overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full",
                isGarbage ? "bg-issue-garbage" : "bg-issue-streetlight"
              )}
              style={{ width: `${confidencePercent}%` }}
            />
          </div>
          <span className="text-sm">{confidencePercent}%</span>
        </div>
      </TableCell>
      <TableCell>
        <Select
          value={report.status}
          onValueChange={(value) => onStatusChange(report.id, value as ReportStatus)}
          disabled={isUpdating}
        >
          <SelectTrigger className={cn("w-[140px]", statusClass)}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Open">Open</SelectItem>
            <SelectItem value="In Progress">In Progress</SelectItem>
            <SelectItem value="Resolved">Resolved</SelectItem>
          </SelectContent>
        </Select>
      </TableCell>
      <TableCell className="text-muted-foreground text-sm">
        {formattedDate}
      </TableCell>
    </TableRow>
  );
}
