import { useState } from 'react';
import { Header } from '@/components/Header';
import { ImageUploader } from '@/components/ImageUploader';
import { DetectionResult } from '@/components/DetectionResult';
import { uploadAndDetect } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import type { Report, Location } from '@/types/report';
import { AlertCircle, FileWarning, ArrowRight, Trash2, CircleDot, Lightbulb } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Index = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<Report | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleUpload = async (file: File, location?: Location) => {
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await uploadAndDetect(file, location);

      if (response.success && response.report) {
        setResult(response.report);
        toast({
          title: 'Report Submitted',
          description: `${response.report.issue_type} detected with ${Math.round(response.report.confidence * 100)}% confidence.`,
        });
      } else {
        setError(response.error || 'Failed to process image');
        toast({
          title: 'Error',
          description: response.error || 'Failed to process image',
          variant: 'destructive',
        });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An unexpected error occurred';
      setError(message);
      toast({
        title: 'Error',
        description: message,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewReport = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 md:py-12">
        <div className="max-w-xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-3 animate-fade-in">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
              Report a Civic Issue
            </h1>
            <p className="text-muted-foreground text-lg max-w-md mx-auto">
              Take a photo of any civic issue. Our AI powered by YOLOv8 will automatically detect and classify it.
            </p>
          </div>

          {/* Supported Issues */}
          <div className="flex flex-wrap items-center justify-center gap-3 text-sm">
            <span className="text-muted-foreground">Detects:</span>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 rounded-full issue-garbage border font-medium flex items-center gap-1.5">
                <Trash2 className="h-3.5 w-3.5" />
                Garbage
              </span>
              <span className="px-3 py-1 rounded-full issue-pothole border font-medium flex items-center gap-1.5">
                <CircleDot className="h-3.5 w-3.5" />
                Pothole
              </span>
              <span className="px-3 py-1 rounded-full issue-streetlight border font-medium flex items-center gap-1.5">
                <Lightbulb className="h-3.5 w-3.5" />
                Broken Streetlight
              </span>
            </div>
          </div>

          {/* Upload Section */}
          {!result && (
            <div className="bg-card rounded-2xl border p-6 shadow-sm animate-scale-in">
              <ImageUploader onUpload={handleUpload} isLoading={isLoading} />
            </div>
          )}

          {/* Error State */}
          {error && (
            <Alert variant="destructive" className="animate-fade-in">
              <FileWarning className="h-4 w-4" />
              <AlertDescription className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                {error}
              </AlertDescription>
            </Alert>
          )}

          {/* Result Section */}
          {result && (
            <div className="space-y-4">
              <DetectionResult report={result} />
              
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={handleNewReport}
                  variant="outline"
                  className="flex-1"
                >
                  Submit Another Report
                </Button>
                <Button asChild className="flex-1">
                  <Link to="/feed">
                    View All Reports
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Index;
