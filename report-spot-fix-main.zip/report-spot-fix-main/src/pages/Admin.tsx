import { useEffect, useState } from 'react';
import { Header } from '@/components/Header';
import { AdminReportRow } from '@/components/AdminReportRow';
import { getReports, updateReportStatus } from '@/lib/api';
import type { Report, ReportStatus } from '@/types/report';
import { Loader2, FileQuestion, Shield, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const Admin = () => {
  const [reports, setReports] = useState<Report[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchReports = async () => {
    setIsLoading(true);
    const data = await getReports();
    setReports(data);
    setIsLoading(false);
  };

  useEffect(() => {
    fetchReports();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('reports-admin')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reports',
        },
        () => {
          fetchReports();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleStatusChange = async (id: string, status: ReportStatus) => {
    setUpdatingId(id);
    const success = await updateReportStatus(id, status);
    
    if (success) {
      toast({
        title: 'Status Updated',
        description: `Report status changed to "${status}"`,
      });
      // Optimistic update
      setReports(prev => 
        prev.map(r => r.id === id ? { ...r, status } : r)
      );
    } else {
      toast({
        title: 'Error',
        description: 'Failed to update status',
        variant: 'destructive',
      });
    }
    setUpdatingId(null);
  };

  const totalReports = reports.length;
  const openReports = reports.filter(r => r.status === 'Open').length;
  const inProgressReports = reports.filter(r => r.status === 'In Progress').length;
  const resolvedReports = reports.filter(r => r.status === 'Resolved').length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 md:py-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-foreground">
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground text-sm">
                Manage and update report statuses
              </p>
            </div>
          </div>
          <Button 
            variant="outline" 
            onClick={fetchReports}
            disabled={isLoading}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border rounded-xl p-4 animate-fade-in">
            <p className="text-3xl font-bold text-foreground">{totalReports}</p>
            <p className="text-sm text-muted-foreground">Total Reports</p>
          </div>
          <div className="bg-card border rounded-xl p-4 animate-fade-in" style={{ animationDelay: '0.05s' }}>
            <p className="text-3xl font-bold text-status-open">{openReports}</p>
            <p className="text-sm text-muted-foreground">Open</p>
          </div>
          <div className="bg-card border rounded-xl p-4 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <p className="text-3xl font-bold text-status-progress">{inProgressReports}</p>
            <p className="text-sm text-muted-foreground">In Progress</p>
          </div>
          <div className="bg-card border rounded-xl p-4 animate-fade-in" style={{ animationDelay: '0.15s' }}>
            <p className="text-3xl font-bold text-status-resolved">{resolvedReports}</p>
            <p className="text-sm text-muted-foreground">Resolved</p>
          </div>
        </div>

        {/* Reports Table */}
        <div className="bg-card border rounded-xl overflow-hidden animate-fade-in" style={{ animationDelay: '0.2s' }}>
          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : reports.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <FileQuestion className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">No reports yet</h3>
              <p className="text-muted-foreground mt-1">
                Reports will appear here once submitted
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Image</TableHead>
                  <TableHead>Issue Type</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reported At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <AdminReportRow
                    key={report.id}
                    report={report}
                    onStatusChange={handleStatusChange}
                    isUpdating={updatingId === report.id}
                  />
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </main>
    </div>
  );
};

export default Admin;
