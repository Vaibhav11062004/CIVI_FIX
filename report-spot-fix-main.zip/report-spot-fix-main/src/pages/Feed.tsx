import { useEffect, useState } from 'react';
import { Header } from '@/components/Header';
import { ReportCard } from '@/components/ReportCard';
import { getReports } from '@/lib/api';
import type { Report } from '@/types/report';
import { Loader2, FileQuestion, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

const Feed = () => {
  const [reports, setReports] = useState<Report[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchReports = async () => {
    setIsLoading(true);
    const data = await getReports();
    setReports(data);
    setIsLoading(false);
  };

  useEffect(() => {
    fetchReports();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('reports-feed')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reports',
        },
        () => {
          fetchReports();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const totalReports = reports.length;
  const openReports = reports.filter(r => r.status === 'Open').length;
  const resolvedReports = reports.filter(r => r.status === 'Resolved').length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 md:py-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8 animate-fade-in">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">
              Public Issues Feed
            </h1>
            <p className="text-muted-foreground mt-1">
              All reported civic issues in your community
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={fetchReports}
            disabled={isLoading}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-card border rounded-xl p-4 text-center animate-fade-in">
            <p className="text-2xl font-bold text-foreground">{totalReports}</p>
            <p className="text-sm text-muted-foreground">Total Reports</p>
          </div>
          <div className="bg-card border rounded-xl p-4 text-center animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <p className="text-2xl font-bold text-status-open">{openReports}</p>
            <p className="text-sm text-muted-foreground">Open</p>
          </div>
          <div className="bg-card border rounded-xl p-4 text-center animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <p className="text-2xl font-bold text-status-resolved">{resolvedReports}</p>
            <p className="text-sm text-muted-foreground">Resolved</p>
          </div>
        </div>

        {/* Reports Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : reports.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <FileQuestion className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">No reports yet</h3>
            <p className="text-muted-foreground mt-1">
              Be the first to report a civic issue in your community
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map((report, index) => (
              <div 
                key={report.id} 
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <ReportCard report={report} />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Feed;
