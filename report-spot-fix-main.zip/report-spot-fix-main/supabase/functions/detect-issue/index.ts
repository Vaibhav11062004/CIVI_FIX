import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const formData = await req.formData();
    const imageFile = formData.get('image') as File;
    const latitude = formData.get('latitude') as string | null;
    const longitude = formData.get('longitude') as string | null;
    const address = formData.get('address') as string | null;

    if (!imageFile) {
      return new Response(
        JSON.stringify({ success: false, error: 'No image provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Received image for detection:', imageFile.name, imageFile.type, imageFile.size);
    console.log('Location data:', { latitude, longitude, address });

    // Get AI detection endpoint from environment
    const detectEndpoint = Deno.env.get('AI_DETECT_ENDPOINT');
    
    let detectionResult;
    
    if (detectEndpoint) {
      // Call external YOLOv8 detection API
      console.log('Calling external YOLOv8 detection API:', detectEndpoint);
      
      const detectFormData = new FormData();
      detectFormData.append('image', imageFile);

      try {
        const response = await fetch(`${detectEndpoint}/detect`, {
          method: 'POST',
          body: detectFormData,
        });

        if (!response.ok) {
          throw new Error(`Detection API returned ${response.status}`);
        }

        detectionResult = await response.json();
        console.log('YOLOv8 detection result:', detectionResult);
      } catch (apiError) {
        console.error('Detection API error:', apiError);
        // Fallback to mock detection if API is unavailable
        detectionResult = getMockDetection(imageFile.name);
        console.log('Using mock detection due to API error:', detectionResult);
      }
    } else {
      // Mock detection for development/demo
      console.log('No AI_DETECT_ENDPOINT configured, using mock YOLOv8 detection');
      detectionResult = getMockDetection(imageFile.name);
    }

    // Upload image to Supabase Storage
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const fileName = `${Date.now()}-${imageFile.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const arrayBuffer = await imageFile.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('report-images')
      .upload(fileName, uint8Array, {
        contentType: imageFile.type,
        upsert: false,
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to upload image' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('report-images')
      .getPublicUrl(fileName);

    const imageUrl = urlData.publicUrl;
    console.log('Image uploaded to:', imageUrl);

    // Prepare report data with optional location
    const reportData: Record<string, unknown> = {
      image_url: imageUrl,
      issue_type: detectionResult.issue_type,
      confidence: detectionResult.confidence,
      status: 'Open',
    };

    // Add location data if provided
    if (latitude && longitude) {
      reportData.latitude = parseFloat(latitude);
      reportData.longitude = parseFloat(longitude);
    }
    if (address) {
      reportData.address = address;
    }

    // Save report to database
    const { data: report, error: insertError } = await supabase
      .from('reports')
      .insert(reportData)
      .select()
      .single();

    if (insertError) {
      console.error('Insert error:', insertError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to save report' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Report created:', report.id);

    return new Response(
      JSON.stringify({
        success: true,
        report: report,
        detection: detectionResult,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error processing request:', error);
    return new Response(
      JSON.stringify({ success: false, error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Mock YOLOv8 detection for development/demo when AI service is unavailable
// Simulates what a YOLOv8 model would return for civic issue detection
function getMockDetection(fileName: string): { issue_type: string; confidence: number } {
  const lowerName = fileName.toLowerCase();
  
  // Simple heuristic based on filename for demo
  if (lowerName.includes('garbage') || lowerName.includes('trash') || lowerName.includes('waste') || lowerName.includes('litter')) {
    return { issue_type: 'Garbage', confidence: 0.92 };
  }
  if (lowerName.includes('pothole') || lowerName.includes('hole') || lowerName.includes('road') || lowerName.includes('crack')) {
    return { issue_type: 'Pothole', confidence: 0.89 };
  }
  if (lowerName.includes('light') || lowerName.includes('street') || lowerName.includes('lamp') || lowerName.includes('pole')) {
    return { issue_type: 'Broken Streetlight', confidence: 0.88 };
  }
  
  // Random assignment for demo purposes - simulating YOLOv8 detection
  const issueTypes = ['Garbage', 'Pothole', 'Broken Streetlight'];
  const randomIndex = Math.floor(Math.random() * issueTypes.length);
  const confidence = 0.70 + Math.random() * 0.25;
  
  return { 
    issue_type: issueTypes[randomIndex], 
    confidence: parseFloat(confidence.toFixed(2))
  };
}
