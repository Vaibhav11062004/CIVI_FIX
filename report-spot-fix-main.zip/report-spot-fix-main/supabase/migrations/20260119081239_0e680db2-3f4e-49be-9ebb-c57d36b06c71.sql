-- Create reports table for civic issues
CREATE TABLE public.reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_url TEXT NOT NULL,
  issue_type TEXT NOT NULL,
  confidence DECIMAL(4,3) NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
  status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Resolved')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- Public read access - anyone can view reports
CREATE POLICY "Anyone can view reports" 
ON public.reports 
FOR SELECT 
USING (true);

-- Public insert access - anyone can create reports
CREATE POLICY "Anyone can create reports" 
ON public.reports 
FOR INSERT 
WITH CHECK (true);

-- Public update access for status changes (admin functionality)
CREATE POLICY "Anyone can update reports" 
ON public.reports 
FOR UPDATE 
USING (true);

-- Create storage bucket for report images
INSERT INTO storage.buckets (id, name, public)
VALUES ('report-images', 'report-images', true);

-- Allow public to upload images
CREATE POLICY "Anyone can upload report images"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'report-images');

-- Allow public to view report images
CREATE POLICY "Anyone can view report images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'report-images');

-- Enable realtime for reports
ALTER PUBLICATION supabase_realtime ADD TABLE public.reports;