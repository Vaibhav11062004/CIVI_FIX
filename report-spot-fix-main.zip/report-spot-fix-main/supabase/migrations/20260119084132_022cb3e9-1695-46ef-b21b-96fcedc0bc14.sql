-- Add location columns to reports table
ALTER TABLE public.reports 
ADD COLUMN latitude NUMERIC,
ADD COLUMN longitude NUMERIC,
ADD COLUMN address TEXT;

-- Add Pothole as supported issue type (no constraint, just documentation)
-- Update mock values will include: Garbage, Pothole, Broken Streetlight